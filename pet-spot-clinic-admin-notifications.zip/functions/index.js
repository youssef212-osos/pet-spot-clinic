const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const logger = require('firebase-functions/logger');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();

async function notifyAllAdmins({ title, body, type, id }) {
  const snapshot = await db.collection('adminPushTokens').where('enabled', '==', true).get();
  if (snapshot.empty) {
    logger.info('No enabled admin push tokens found.');
    return;
  }

  const tokenDocs = snapshot.docs.filter((doc) => doc.data().token);
  const tokens = tokenDocs.map((doc) => doc.data().token);
  if (!tokens.length) return;

  const response = await messaging.sendEachForMulticast({
    tokens,
    notification: { title, body },
    data: {
      type,
      id: String(id || ''),
      click_action: 'OPEN_ADMIN'
    },
    webpush: {
      fcmOptions: { link: '/pet-spot-clinic/' },
      notification: {
        icon: '/pet-spot-clinic/icon-192.png',
        badge: '/pet-spot-clinic/icon-192.png'
      }
    }
  });

  const cleanup = [];
  response.responses.forEach((result, index) => {
    if (!result.success) {
      const code = result.error && result.error.code;
      if (code === 'messaging/registration-token-not-registered' || code === 'messaging/invalid-registration-token') {
        cleanup.push(tokenDocs[index].ref.delete());
      }
    }
  });
  await Promise.all(cleanup);
  logger.info(`Admin notification sent: ${response.successCount} success, ${response.failureCount} failed.`);
}

exports.notifyAdminsOnOrder = onDocumentCreated('orders/{orderId}', async (event) => {
  const order = event.data && event.data.data();
  if (!order) return;
  const orderNumber = order.orderNumber || event.params.orderId;
  const customer = order.customer && order.customer.name ? order.customer.name : 'Customer';
  await notifyAllAdmins({
    title: '🛍️ New Pet Spot Order',
    body: `${orderNumber} • ${customer} • ${order.total || 0} EGP`,
    type: 'order',
    id: event.params.orderId
  });
});

exports.notifyAdminsOnBooking = onDocumentCreated('bookings/{bookingId}', async (event) => {
  const booking = event.data && event.data.data();
  if (!booking) return;
  await notifyAllAdmins({
    title: '📅 New Pet Spot Booking',
    body: `${booking.service || 'Appointment'} • ${booking.name || 'Customer'} • ${booking.date || ''} ${booking.time || ''}`.trim(),
    type: 'booking',
    id: event.params.bookingId
  });
});
